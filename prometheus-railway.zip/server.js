/**
 * Prometheus obfuscation service for Jason Auth.
 *
 * Wraps https://github.com/prometheus-lua/Prometheus in a tiny HTTP API:
 *   POST /  { "source": "<lua code>", "preset": "Minify|Weak|Medium|Strong|Vmify" }
 *   -> 200 { "output": "<obfuscated lua>" }
 *   -> 4xx/5xx { "error": "<message>" }
 *
 * Auth: if PROMETHEUS_TOKEN is set, requests must send
 *   Authorization: Bearer <PROMETHEUS_TOKEN>
 *
 * The Jason Auth website already calls it this way — you only need to
 * deploy this and send the site your public URL + token.
 */
const http = require("http");
const { spawn } = require("child_process");
const fs = require("fs");
const path = require("path");
const os = require("os");
const crypto = require("crypto");

const PORT = Number(process.env.PORT || 8787);
const TOKEN = process.env.PROMETHEUS_TOKEN || "";
const PROM_DIR = process.env.PROMETHEUS_DIR || path.join(__dirname, "Prometheus");
const LUA_BIN = process.env.LUA_BIN || "lua5.1";
const TIMEOUT_MS = Number(process.env.TIMEOUT_MS || 30000);
const PRESETS = ["Minify", "Weak", "Medium", "Strong", "Vmify"];

function obfuscate(source, preset) {
  return new Promise((resolve, reject) => {
    const id = crypto.randomBytes(8).toString("hex");
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "prom-"));
    const inFile = path.join(tmp, `in-${id}.lua`);
    const outFile = path.join(tmp, `out-${id}.lua`);
    fs.writeFileSync(inFile, source, "utf8");

    // Prometheus CLI: lua cli.lua --preset <Preset> --out <out> <in>
    const args = [path.join(PROM_DIR, "cli.lua"), "--preset", preset, "--out", outFile, inFile];
    const child = spawn(LUA_BIN, args, { cwd: PROM_DIR, timeout: TIMEOUT_MS });

    let stderr = "";
    child.stderr.on("data", (d) => (stderr += d));
    child.on("error", (err) => {
      cleanup();
      reject(new Error(`Failed to run Lua (${LUA_BIN}): ${err.message}`));
    });
    child.on("close", (code) => {
      try {
        if (code === 0 && fs.existsSync(outFile)) {
          resolve(fs.readFileSync(outFile, "utf8"));
        } else {
          reject(new Error(stderr.trim() || `Prometheus exited with code ${code}`));
        }
      } finally {
        cleanup();
      }
    });

    function cleanup() {
      try {
        fs.rmSync(tmp, { recursive: true, force: true });
      } catch {}
    }
  });
}

const server = http.createServer(async (req, res) => {
  const send = (code, obj) => {
    res.writeHead(code, { "content-type": "application/json" });
    res.end(JSON.stringify(obj));
  };

  if (req.method === "GET" && (req.url === "/" || req.url === "/health")) {
    return send(200, { status: "ok", presets: PRESETS });
  }
  if (req.method !== "POST") return send(405, { error: "Method not allowed" });

  if (TOKEN) {
    const auth = req.headers["authorization"] || "";
    if (auth !== `Bearer ${TOKEN}`) return send(401, { error: "Unauthorized" });
  }

  let body = "";
  req.on("data", (c) => {
    body += c;
    if (body.length > 2_000_000) req.destroy(); // 2MB cap
  });
  req.on("end", async () => {
    try {
      const { source, preset } = JSON.parse(body || "{}");
      if (typeof source !== "string" || !source.trim()) return send(400, { error: "Missing source" });
      const p = PRESETS.includes(preset) ? preset : "Medium";
      const output = await obfuscate(source, p);
      send(200, { output });
    } catch (err) {
      send(500, { error: err.message || "Obfuscation failed" });
    }
  });
});

server.listen(PORT, () =>
  console.log(`Prometheus service listening on :${PORT} (dir: ${PROM_DIR}, lua: ${LUA_BIN})`),
);
