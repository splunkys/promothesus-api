# Prometheus service for Jason Auth — Railway deploy

A tiny HTTP wrapper around [Prometheus](https://github.com/prometheus-lua/Prometheus)
so the Jason Auth website can obfuscate Lua scripts for free members.

This folder is ready to drop straight into a GitHub repo — Railway builds it
from the `Dockerfile` automatically.

## Files

| File | What it does |
| --- | --- |
| `server.js` | The service. Receives Lua, returns obfuscated Lua. |
| `Dockerfile` | Builds a container with Lua 5.1 + Prometheus inside. |
| `railway.json` | Tells Railway how to build and health-check the app. |
| `.gitignore` | Keeps junk out of the repo. |

## Deploy on Railway (about 5 minutes)

1. **Upload these 4 files to GitHub.**
   Go to github.com → **New repository** → name it `prometheus-service` →
   **Add file → Upload files** → drag in `server.js`, `Dockerfile`,
   `railway.json`, `.gitignore` → **Commit changes**.
   (Make sure they are in the top level of the repo, not inside a folder.)

2. **Create the Railway project.**
   Go to railway.app → sign up with your GitHub account →
   **New Project** → **Deploy from GitHub repo** → pick `prometheus-service`.
   Railway reads the `Dockerfile` and builds it. First build takes a few minutes.

3. **Add your secret token.**
   Open the service → **Variables** tab → **New Variable**:
   - Name: `PROMETHEUS_TOKEN`
   - Value: any strong password you invent (e.g. run `openssl rand -hex 32`,
     or just mash the keyboard for 30+ characters). **Write it down.**

4. **Get the public address.**
   Open the service → **Settings** → **Networking** → **Generate Domain**.
   You get an address like
   `https://prometheus-service-production-xxxx.up.railway.app`.

5. **Check it is alive.**
   Open that address in a browser — you should see
   `{"status":"ok","presets":[...]}`.

6. **Tell me the address and the token** in chat and I'll save them into the
   website. Then **Prometheus** protection works for free members.

## Test it by hand

Replace the URL and token below with your own:

```sh
curl -X POST https://YOUR-RAILWAY-ADDRESS/ \
  -H "Authorization: Bearer YOUR-TOKEN" \
  -H "content-type: application/json" \
  -d '{"source":"print(\"hi\")","preset":"Medium"}'
```

You should get back `{"output":"return(function(...)local ..."}`.

## Run it locally instead (optional)

```sh
docker build -t prometheus-service .
docker run -d -p 8787:8787 -e PROMETHEUS_TOKEN=choose-a-secret prometheus-service
```

## Presets

`Minify`, `Weak`, `Medium`, `Strong`, `Vmify`. The website sends `Medium`.
